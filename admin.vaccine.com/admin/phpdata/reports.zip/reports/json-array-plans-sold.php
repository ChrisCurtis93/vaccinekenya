<?php

require_once('../../data/db.php');
@session_start();
global $db;
$user_id=$_SESSION['user']['userid'];

$response=array();

$plans=$db->GetArray('SELECT * FROM `tb_insurance_plans`');

foreach ($plans as $row) {

	$freq=array();

	$id=$row['plan_id'];

	$count=$db->GetOne("SELECT COUNT(selected_plan_id) FROM tb_selected_plan INNER JOIN tb_customers ON tb_selected_plan.customer_id=tb_customers.user_id WHERE tb_selected_plan.plan_id='$id' AND tb_selected_plan.active_status=1 AND tb_customers.customer_to='$user_id'");

	$freq['plan_type']=$row['plan_name'];
	$freq['total']=$count;

	array_push($response,$freq);
}

echo json_encode($response);


?>