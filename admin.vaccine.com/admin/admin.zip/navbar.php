<?php 
	$obj = new Menu();
?>
<div class="sidebar" data-active-color="rose" data-background-color="black" data-image="../assets/img/sidebar-1.jpg">
	<div class="logo">
        <a href="http://www.creative-tim.com/" class="simple-text">
            <?php echo User::get_details($_SESSION['user']['userid'])["user_details"]["department"]; ?>
        </a>
    </div>
	<div class="logo logo-mini">
		<a href="http://www.creative-tim.com/" class="simple-text">Ct</a>
	</div>
	<div class="sidebar-wrapper">
		<div class="user">
			<div class="photo">
				<img src="assets/img/faces/avatar.jpg" />
			</div>
			<div class="info">
				<a data-toggle="collapse" href="#collapseExample" class="collapsed"> <?php echo User::get_details($_SESSION['user']['userid'])["user_details"]["names"]; ?> <b class="caret"></b></a>
				<div class="collapse" id="collapseExample">
					<ul class="nav">
						<li><a href="#">My Profile</a></li>
						<li><a href="#">Edit Profile</a></li>
						<li><a href="#">Settings</a></li>
					</ul>
                </div>
            </div>
        </div>
		<ul class="nav">
			<li class="active">
				<a href="./">
					<i class="material-icons"> dashboard </i>
					<p>Dashboard</p>
				</a>
			</li>
		
				
				<li>
				
			</li>
			<li>
			

				 <a data-toggle="collapse" href="#pageUsers">
                            <i class="material-icons">people</i>
                            <p>User
                                <b class="caret"></b>
                            </p>
                        </a>
                         <div class="collapse" id="pageUsers">
                            <ul class="nav">
                                <li>
                                    <a href="#"  onclick="open_module('./modules/users/all.php')">All Users</a>
                                </li>
                                <li>
                                    <a href="#" onclick="open_module('./modules/users/new-user.php')">Add Users</a>
                                </li>
                                
                       
                            </ul>
                        </div>

			</li>
			<li>
			
				 <a data-toggle="collapse" href="#pageTables">
                            <i class="material-icons">tables</i>
                            <p>Tables
                                <b class="caret"></b>
                            </p>
                        </a>
                         <div class="collapse" id="pageTables">
                            <ul class="nav">
                                <li>
                                    <a href="#"  onclick="open_module('./modules/tables/all.php')">All tables</a>
                                </li>
                                <li>
                                    <a href="#" onclick="open_module('./modules/tables/add-new-table.php')">Add Table</a>
                                </li>
                                
                       
                            </ul>
                        </div>
			</li>
		<li>
				

				 <a data-toggle="collapse" href="#pageOrders">
                            <i class="material-icons">list</i>
                            <p>Orders
                                <b class="caret"></b>
                            </p>
                        </a>
                         <div class="collapse" id="pageOrders">
                            <ul class="nav">
                                <li>
                                    <a href="#" onclick="open_module('./modules/orders/all.php')">All Orders</a>
                                </li>
                                <li>
                                    <a href="#" onclick="open_module('./modules/orders/view-closed-orders.php')">Closed Orders</a>
                                </li>
                                
                       
                            </ul>
                        </div>
			</li>

			   <li>
                        <a data-toggle="collapse" href="#pageMenu">
                            <i class="material-icons">image</i>
                            <p>Menu
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="pageMenu">
                            <ul class="nav">
                                <li>
                                    <a href="#">Category</a>
                                </li>
                                <li>
                                    <a href="#">Sub Category</a>
                                </li>
                                <li>
                                    <a href="#">Menu Items</a>
                                </li>
                       
                            </ul>
                        </div>
                    </li>
			
			<?php $obj->create_menu(User::get_details($_SESSION['user']['userid'])["user_details"]["departmentid"]); ?>
		</ul>
	</div>
</div>