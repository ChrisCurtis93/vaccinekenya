function delete_user(value){


		var url="./phpdata/admin-delete-user.php?userId="+value;

			$.ajax({
			url:url,
			type:"GET",
			dataType:"json",
			success: function(response){

				var newData = response.success;
				if(newData==1){

					swal("User status", response.message,"success");
					open_module('./modules/users/all.php');

				}else{
					swal("Not deleted",response.message,"error");

				}
			}

		});

	
}
