function add_user(){

		var user_name=document.getElementById("name").value;
		var user_email=document.getElementById("email").value;
		var user_phoneNumber=document.getElementById("phoneNumber").value;
		var branchName=get_user_branch();
		var userCategory=get_user_category();
		
		var values="name="+user_name+"&email="+user_email+"&phone="+user_phoneNumber+"&branch="+branchName+"&category="+userCategory;
		var url="./modules/users/add-new-user.php?"+values;


		$.ajax({
			url:url,
			type:"GET",
			url:url,
			dataType:"json",
			success: function(response){

				var newData = response.success;
				if(newData==1){

					swal("User status", response.message,"success");
					open_module('./modules/users/all.php');

				}else{
					swal("User status",response.message,"warning");

				}
			}

		});
	}

	function get_user_category(){
	
		var user_branch=document.getElementById("select_user_category").value;
		return user_branch;
	}
	function get_user_branch(){
		var user_branch=document.getElementById("select_branch").value;
		return user_branch;
	}
	
	function get_user_branch_table(){
		var user_branch=document.getElementById("select_branch_table").value;
		return user_branch;
	}
	function add_table(){

		var tab_name=document.getElementById("table_name").value;
		var branchName=get_user_branch_table();

		var values="table_name="+tab_name+"&branchId="+branchName;
		var url="./modules/tables/add-table.php?"+values;


		$.ajax({
			url:url,
			type:"GET",
			url:url,
			dataType:"json",
			success: function(response){

				var newData = response.success;
				if(newData==1){

					swal("Table status", response.message,"success");
						open_module('./modules/table/all.php');

				}else{
					swal("User status",response.message,"warning");

				}
			}

		});
	}