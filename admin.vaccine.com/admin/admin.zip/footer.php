<footer class="footer">
    <div class="container-fluid">
		<?php echo App::get_app_details()["app_details"]["copyright"]; ?>
	</div>
</footer>